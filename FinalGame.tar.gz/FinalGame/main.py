

import sys, pygame

import map, camera, player, timer, finish

from image_loader import load_image

from pygame.locals import *

CENTER_W = -1
CENTER_H = -1

engine = []
wheel = []
gearbox = []
breakpedal = []
steeringwheel = []

#Main Game Loop
def main():
#Initialize objects
    clock = pygame.time.Clock()
    quit = False
    font = pygame.font.Font(None, 24)
    car = player.Player()
    cam = camera.Camera()
    timer.initialize(CENTER_W, CENTER_H)
    aim = timer.Finish()

    engine = [timer.Engine() for i in range (0,2)]

    wheel = [timer.Wheels() for i in range (0,8)]
    steeringwheel = [timer.SteeringWheel() for i in range (0,3)]
    gearbox = [timer.Gearbox() for i in range (0,3)]
    breakpedal = [timer.BreakPedal() for i in range (0,5)]

    finish1 = finish.Alert()


    map1 = pygame.sprite.Group()
    player1 = pygame.sprite.Group()
    engines = pygame.sprite.Group()
    wheels = pygame.sprite.Group()
    steeringwheels = pygame.sprite.Group()
    gearboxes = pygame.sprite.Group()
    breakpedals = pygame.sprite.Group()

    timeout = pygame.sprite.Group()

    #generate tiles
    for tile_num in range (0, len(map.map_tiles)):
        map.map_files.append(load_image(map.map_tiles[tile_num], False))
    for x in range (0, 25):
        for y in range (0, 25):
            map1.add(map.Map(map.map_1[x][y], x * 400, y * 400))

    for i in range (0,2):
        engines.add(engine[i])

    for i in range (0,8):
        wheels.add(wheel[i])

    for i in range (0,3):
        steeringwheels.add(steeringwheel[i])

    for i in range (0,3):
        gearboxes.add(gearbox[i])

    for i in range (0,5):
        breakpedals.add(breakpedal[i])

    timeout.add(finish1)

    player1.add(car)

    cam.set_pos(car.x, car.y)

    aim.ReverseInsertionSort()


    while not quit:


    #Check for menu/reset, (keyup event - trigger ONCE)
        for event in pygame.event.get():
            if event.type == pygame.KEYUP:
                if (keys[K_q]):
                    pygame.quit()
                    sys.exit(0)

            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                quit = True
                break

    #Check for key input. (KEYDOWN, trigger often)
        keys = pygame.key.get_pressed()
        #if (target.timeleft > 0):
        if keys[K_LEFT]:
            car.steerleft()
        if keys[K_RIGHT]:
            car.steerright()
        if keys[K_UP]:
            car.accelerate()
        else:
            car.soften()
        if keys[K_DOWN]:
            car.deaccelerate()

        cam.set_pos(car.x, car.y)



        #Show text data.
        text_fps = font.render('FPS: ' + str(int(clock.get_fps())), 1, (224, 16, 16))
        textpos_fps = text_fps.get_rect(centery=25, centerx=60)

        text_score = font.render('Score: ' + str(aim.score), 1, (224, 16, 16))
        textpos_score = text_fps.get_rect(centery=45, centerx=60)

        text_timer = font.render('Timer: ' + str(int((aim.timeleft / 60)/60)) + ":" + str(int((aim.timeleft / 60) % 60)), 1, (224, 16, 16))
        textpos_timer = text_fps.get_rect(centery=65, centerx=60)

        text_first = font.render(str(aim.first), 1, (255,255,255))
        textpos_first = text_fps.get_rect(centery=150, centerx=60)

        text_second = font.render(str(aim.second), 1, (255,255,255))
        textpos_second = text_fps.get_rect(centery=170, centerx=60)

        text_third = font.render(str(aim.third), 1, (255,255,255))
        textpos_third = text_fps.get_rect(centery=190, centerx=60)

        text_fourth = font.render(str(aim.fourth), 1, (255,255,255))
        textpos_fourth = text_fps.get_rect(centery=210, centerx=60)

        text_fith = font.render(str(aim.fith), 1, (255,255,255))
        textpos_fith = text_fps.get_rect(centery=230, centerx=60)

        #Render Scene.
        window.blit(background, (0,0))


        map1.update(cam.x, cam.y)
        map1.draw(window)

        car.grass(window.get_at(((CENTER_W + 25, CENTER_H + 50))).g)


        #aim.ReverseInsertionSort()

        player1.update(cam.x, cam.y)
        player1.draw(window)

        for i in range (0,2):
            engine[i].update(cam.x, cam.y)
            if pygame.sprite.spritecollide(car, engines, True):
                engine[i].claim_item()
                engine[i].generate_finish()
                engine[i].add(engines)
                aim.ReverseInsertionSort()


        for i in range (0,8):
            wheel[i].update(cam.x, cam.y)
            if pygame.sprite.spritecollide(car, wheels, True):
                wheel[i].claim_item()
                wheel[i].generate_finish()
                wheel[i].add(wheels)
                aim.ReverseInsertionSort()

        for i in range (0,3):
            gearbox[i].update(cam.x, cam.y)
            if pygame.sprite.spritecollide(car, gearboxes, True):
                gearbox[i].claim_item()
                gearbox[i].generate_finish()
                gearbox[i].add(gearboxes)
                aim.ReverseInsertionSort()

        for i in range (0,3):
            steeringwheel[i].update(cam.x, cam.y)
            if pygame.sprite.spritecollide(car, steeringwheels, True):
                steeringwheel[i].claim_item()
                steeringwheel[i].generate_finish()
                steeringwheel[i].add(steeringwheels)
                aim.ReverseInsertionSort()

        for i in range (0,5):
            breakpedal[i].update(cam.x, cam.y)
            if pygame.sprite.spritecollide(car, breakpedals, True):
                breakpedal[i].claim_item()
                breakpedal[i].generate_finish()
                breakpedal[i].add(breakpedals)
                aim.ReverseInsertionSort()





        engines.draw(window)
        wheels.draw(window)
        gearboxes.draw(window)
        steeringwheels.draw(window)
        breakpedals.draw(window)

        if (aim.timeleft == 0):
            timeout.draw(window)
            car.speed = 0
            font = pygame.font.Font(None, 42)
            text_score = font.render('Final Score: ' + str(aim.score), 1, (224, 16, 16))
            textpos_score = text_fps.get_rect(centery=CENTER_H/2+200, centerx=CENTER_W-60)
            textpos_first = text_fps.get_rect(centery=CENTER_H/2+250, centerx=CENTER_W-40)
            textpos_second = text_fps.get_rect(centery=CENTER_H/2+280, centerx=CENTER_W-40)
            textpos_third = text_fps.get_rect(centery=CENTER_H/2+310, centerx=CENTER_W-40)
            textpos_fourth = text_fps.get_rect(centery=CENTER_H/2+340, centerx=CENTER_W-40)
            textpos_fith = text_fps.get_rect(centery=CENTER_H/2+370, centerx=CENTER_W-40)
            aim.bubblesort()

        font = pygame.font.Font(None, 24)
        window.blit(text_fps, textpos_fps)
        window.blit(text_score, textpos_score)
        window.blit(text_timer, textpos_timer)
        window.blit(text_first, textpos_first)
        window.blit(text_second, textpos_second)
        window.blit(text_third, textpos_third)
        window.blit(text_fourth, textpos_fourth)
        window.blit(text_fith, textpos_fith)
        pygame.display.flip()

        aim.update()

        clock.tick(64)














pygame.init()

window = pygame.display.set_mode((pygame.display.Info().current_w,
                                  pygame.display.Info().current_h),
                                  pygame.FULLSCREEN)

pygame.mouse.set_visible(False)
font = pygame.font.Font(None, 24)

CENTER_W =  int(pygame.display.Info().current_w /2)
CENTER_H =  int(pygame.display.Info().current_h /2)

#new background surface
background = pygame.Surface(window.get_size())
background = background.convert_alpha()
background.fill((26, 26, 26))

#Enter the mainloop.
main()

pygame.quit()
sys.exit(0)