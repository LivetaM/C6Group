
class Camera():
    def __init__(self):
        self.x = 500
        self.y = 500

    def set_pos(self, x, y):
        self.x = x
        self.y = y