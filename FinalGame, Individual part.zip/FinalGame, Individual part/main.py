import sys, pygame
from tkinter import *
import tkinter as Toplevel
import tkinter as Tk
import tkinter as Label
import tkinter as Button
import map, camera, player, timer, finish
from image_loader import load_image
from pygame.locals import *

CENTER_W = -1
CENTER_H = -1

engine = []
wheel = []
gearbox = []
breakpedal = []
steeringwheel = []
class GUI():
    root = Tk.Tk()
    root.title('Car part hunt')
    width = 200 # width for the window
    height = 400 # height for the window

    # getting screen dimensions
    ws = root.winfo_screenwidth() # width of the screen
    hs = root.winfo_screenheight() # height of the screen

    # calculating coordinates for the window
    x = (ws/2) - (width/2)
    y = (hs/2) - (height/2)

    # setting up screen dimensions
    # where window is placed
    root.geometry('%dx%d+%d+%d' % (width, height, x, y))
    root.lift(aboveThis=None)
    def endProgram():
        raise SystemExit
        sys.exit(main)

        
    def tutorial():
        top = Toplevel.Toplevel()
        top.title("Tutorial and Game idea")
        width = 800 # width for the window
        height = 550 # height for the window

        # getting screen dimensions
        ws = top.winfo_screenwidth() # width of the screen
        hs = top.winfo_screenheight() # height of the screen
        
        # calculating coordinates for the window
        x = (ws/2) - (width/2)
        y = (hs/2) - (height/2)
        top.geometry('%dx%d+%d+%d' % (width, height, x, y))
        top.configure(background='lightblue')
        

        # setting up screen dimensions
        # where window is placed

        msg = Toplevel.Message(top, text="HELLO!\n   Welcome to the car part hunt game tutorial! Here you will find out what game it is and how to play it. \n   Imagine this: You are the best racer in the world, but suddenly you hear about this new guy, that wins all his racing championships and in two weeks you will be the last one, he will get a chance to race and it is the championship of the year. So, what do you do? you start to prepare. Not just emotionally, you also decide to build a brand new car, with best parts in it because you want to have bigger chances to win. You want that trophy and to stay the best of the best, right? Then what are you waiting for? hop in to your car and go for a hunt! You have to be fast because someone else (and I mean your opponent) wants those car parts too.\n   GOOD LUCK! \nControlling the game:\nThe controls are very simple:\nUP ARROW KEY - To move forward\nLEFT ARROW KEY - To turn left\nRIGHT ARROW KEY - To turn right\nDOWN ARROW KEY - To move backwards\nESC KEY - To turn off the game and get back to the menu window")
        msg.config(bg='lightblue', font=('times', 20, 'italic'))
        msg.pack()
        button = Toplevel.Button(top, text='Exit', command=top.destroy)
        button.pack()
        
        top.mainloop()
        
        
    label = Tk.Label(root, text="Car part hunt game!", fg="brown", font="bold")
    label.pack()
    tutorialButton = Tk.Button(root, text='Tutorial and Game idea', command=tutorial) #tutorial window opening button
    tutorialButton.pack()
    name = Tk.Label(root, text="Racer Name: ") #label for black space to enter racers name
    name.pack()
    entry = Entry(root, bd=5) #blank space to enter the name
    entry.pack()
    label2 = Tk.Label(root, text="Choose items to collect \n(choose at least 1).", fg="blue", font="bold")
    label2.pack()
    #checkbuttons
    CheckVar1 = IntVar()
    CheckVar2 = IntVar()
    CheckVar3 = IntVar()
    CheckVar4 = IntVar()
    CheckVar5 = IntVar()
    C1 = Checkbutton(root, text = "Wheels", variable = CheckVar1, \
                 onvalue = 1, offvalue = 0, height=1, \
                 width = 20)
    C2 = Checkbutton(root, text = "Engine", variable = CheckVar2, \
                 onvalue = 1, offvalue = 0, height=1, \
                 width = 20)
    C3 = Checkbutton(root, text = "Steering wheels", variable = CheckVar3, \
                 onvalue = 1, offvalue = 0, height=1, \
                 width = 20)
    C4 = Checkbutton(root, text = "Break pedals", variable = CheckVar4, \
                 onvalue = 1, offvalue = 0, height=1, \
                 width = 20)
    C5 = Checkbutton(root, text = "Gear boxes", variable = CheckVar5, \
                 onvalue = 1, offvalue = 0, height=1, \
                 width = 20)
    playButton = Tk.Button(root, text='QUIT', command=endProgram and root.destroy) #button to start the game
    playButton.pack(side=BOTTOM)
    quitButton = Tk.Button(root, text = 'PLAY!', command=root.quit)#button to quit the program and main menu
    quitButton.pack(side=BOTTOM)

    C1.pack()
    C2.pack()
    C3.pack()
    C4.pack()
    C5.pack() 
    root.mainloop()

 #This class handles the initilization of pygame along with the drawing of all sprites
#and all nessecary calls to other calsses and functions in order to combine all classes
#and functions together to create a working game

import sys, pygame

import map, camera, player, timer, finish, dijkstras, LinearSearch

from image_loader import load_image

from pygame.locals import *

engine = []
wheel = []
gearbox = []
breakpedal = []
steeringwheel = []

enginelocationX = []
enginelocationY = []

carlocation = []

dijkstras = dijkstras.Graph()

#Main Game Loop
def main():
#Initialize objects
    clock = pygame.time.Clock()
    quit = False
    font = pygame.font.Font(None, 24)
    car = player.Player()
    cam = camera.Camera()
    timer.initialize()
    aim = timer.Finish()
    linear = LinearSearch.LinearSearch()

    #load different numbers of a class and save them as listvariables for
    # iteration over within the while loop
    engine = [timer.Engine() for i in range (0,2)]
    wheel = [timer.Wheels() for i in range (0,8)]
    steeringwheel = [timer.SteeringWheel() for i in range (0,3)]
    gearbox = [timer.Gearbox() for i in range (0,3)]
    breakpedal = [timer.BreakPedal() for i in range (0,5)]

    finish1 = finish.Alert()

    #Set sprite groups for different items
    map1 = pygame.sprite.Group()
    player1 = pygame.sprite.Group()
    engines = pygame.sprite.Group()
    wheels = pygame.sprite.Group()
    steeringwheels = pygame.sprite.Group()
    gearboxes = pygame.sprite.Group()
    breakpedals = pygame.sprite.Group()

    timeout = pygame.sprite.Group()

    #generate tiles
    for tile_num in range (0, len(map.map_tiles)):
        map.map_files.append(load_image(map.map_tiles[tile_num], False))
    for x in range (0, 24):
        for y in range (0, 24):
            map1.add(map.Map(map.map_1[x][y], x * 400, y * 400))


    #Add items to the map with the same number of items as classes created previously
    for i in range (0,2):
        engines.add(engine[i])
        enginelocationX.append(engine[i].returnEngineX())
        enginelocationY.append(engine[i].returnEngineY())

    for i in range (0,8):
        wheels.add(wheel[i])

    for i in range (0,3):
        steeringwheels.add(steeringwheel[i])

    for i in range (0,3):
        gearboxes.add(gearbox[i])

    for i in range (0,5):
        breakpedals.add(breakpedal[i])

    timeout.add(finish1)

    player1.add(car)

    cam.set_pos(car.x, car.y)

    aim.ReverseInsertionSort()

    while not quit:

        closestengine = dijkstras.addnodes(enginelocationX,enginelocationY,int(car.x + 700),int(car.y + 600))
        dijkstras.clearnodes()


    #Check for menu/reset, (keyup event - trigger ONCE)
        for event in pygame.event.get():
            if event.type == pygame.KEYUP:
                if (keys[K_q]):
                    pygame.quit()
                    sys.exit(0)

            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                quit = True
                break

    #Check for key input. (KEYDOWN, trigger often)
        keys = pygame.key.get_pressed()
        #if (target.timeleft > 0):
        if keys[K_LEFT]:
            car.steerleft()
        if keys[K_RIGHT]:
            car.steerright()
        if keys[K_UP]:
            car.accelerate()
        else:
            car.soften()
        if keys[K_DOWN]:
            car.deaccelerate()

        cam.set_pos(car.x, car.y)



        #Show text data.
        text_fps = font.render('FPS: ' + str(int(clock.get_fps())), 1, (224, 16, 16))
        textpos_fps = text_fps.get_rect(centery=25, centerx=60)

        text_score = font.render('Score: ' + str(aim.score), 1, (224, 16, 16))
        textpos_score = text_fps.get_rect(centery=45, centerx=60)

        text_timer = font.render('Timer: ' + str(int((aim.timeleft / 60)/60)) + ":" + str(int((aim.timeleft / 60) % 60)), 1, (224, 16, 16))
        textpos_timer = text_fps.get_rect(centery=65, centerx=60)

        text_first = font.render(str(aim.first), 1, (255,255,255))
        textpos_first = text_fps.get_rect(centery=150, centerx=60)

        text_second = font.render(str(aim.second), 1, (255,255,255))
        textpos_second = text_fps.get_rect(centery=170, centerx=60)

        text_third = font.render(str(aim.third), 1, (255,255,255))
        textpos_third = text_fps.get_rect(centery=190, centerx=60)

        text_fourth = font.render(str(aim.fourth), 1, (255,255,255))
        textpos_fourth = text_fps.get_rect(centery=210, centerx=60)

        text_fith = font.render(str(aim.fith), 1, (255,255,255))
        textpos_fith = text_fps.get_rect(centery=230, centerx=60)

        text_closestengine = font.render("The Closest Engine is: " +linear.linearSearch(list(closestengine[1]), "point1") + " which is " + str(closestengine[0]) + " units from you", 1, (255,255,255))
        textpos_closestengine = text_fps.get_rect(centery = 350, centerx=60)

        linear.reset()

        #Render Scene.
        window.blit(background, (0,0))

        map1.update(cam.x, cam.y)
        map1.draw(window)

        car.grass(window.get_at(((CENTER_W + 25, CENTER_H + 50))).g)

        aim.ReverseInsertionSort()

        player1.update(cam.x, cam.y)
        player1.draw(window)


#Check for collision between the car and all the items placed on the map
#if collision has occured then replace the item in a new location and run reverse insetion sort
        for i in range (0,2):
            engine[i].update(cam.x, cam.y)
            if pygame.sprite.spritecollide(car, engines, True):
                engine[i].claim_item()
                engine[i].generate_finish()
                enginelocationX[i] = engine[i].returnEngineX()
                enginelocationY[i] = engine[i].returnEngineY()
                engine[i].add(engines)
                aim.ReverseInsertionSort()


        for i in range (0,8):
            wheel[i].update(cam.x, cam.y)
            if pygame.sprite.spritecollide(car, wheels, True):
                wheel[i].claim_item()
                wheel[i].generate_finish()
                wheel[i].add(wheels)
                aim.ReverseInsertionSort()

        for i in range (0,3):
            gearbox[i].update(cam.x, cam.y)
            if pygame.sprite.spritecollide(car, gearboxes, True):
                gearbox[i].claim_item()
                gearbox[i].generate_finish()
                gearbox[i].add(gearboxes)
                aim.ReverseInsertionSort()

        for i in range (0,3):
            steeringwheel[i].update(cam.x, cam.y)
            if pygame.sprite.spritecollide(car, steeringwheels, True):
                steeringwheel[i].claim_item()
                steeringwheel[i].generate_finish()
                steeringwheel[i].add(steeringwheels)
                aim.ReverseInsertionSort()

        for i in range (0,5):
            breakpedal[i].update(cam.x, cam.y)
            if pygame.sprite.spritecollide(car, breakpedals, True):
                breakpedal[i].claim_item()
                breakpedal[i].generate_finish()
                breakpedal[i].add(breakpedals)
                aim.ReverseInsertionSort()


#Draw all sprite groups onto window
        engines.draw(window)
        wheels.draw(window)
        gearboxes.draw(window)
        steeringwheels.draw(window)
        breakpedals.draw(window)


#If timer runs down to 0, reposition all text and run bubblesort on the information to reorder and reorganise
        if (aim.timeleft == 0):
            timeout.draw(window)
            car.speed = 0
            font = pygame.font.Font(None, 42)
            text_score = font.render('Final Score: ' + str(aim.score), 1, (224, 16, 16))
            textpos_score = text_fps.get_rect(centery=CENTER_H/2+200, centerx=CENTER_W-60)
            textpos_first = text_fps.get_rect(centery=CENTER_H/2+250, centerx=CENTER_W-40)
            textpos_second = text_fps.get_rect(centery=CENTER_H/2+280, centerx=CENTER_W-40)
            textpos_third = text_fps.get_rect(centery=CENTER_H/2+310, centerx=CENTER_W-40)
            textpos_fourth = text_fps.get_rect(centery=CENTER_H/2+340, centerx=CENTER_W-40)
            textpos_fith = text_fps.get_rect(centery=CENTER_H/2+370, centerx=CENTER_W-40)
            aim.bubblesort()


#Render the text onto the screen using predefined variables for content and position
        font = pygame.font.Font(None, 24)
        window.blit(text_fps, textpos_fps)
        window.blit(text_score, textpos_score)
        window.blit(text_timer, textpos_timer)
        window.blit(text_first, textpos_first)
        window.blit(text_second, textpos_second)
        window.blit(text_third, textpos_third)
        window.blit(text_fourth, textpos_fourth)
        window.blit(text_fith, textpos_fith)
        window.blit(text_closestengine, textpos_closestengine)
        pygame.display.flip()

        aim.update()

        clock.tick(64)













#Initialise pygame and window properties, along with entering the main game loop
pygame.init()

window = pygame.display.set_mode((pygame.display.Info().current_w,
                                  pygame.display.Info().current_h),
                                  pygame.FULLSCREEN)

pygame.mouse.set_visible(False)
font = pygame.font.Font(None, 24)

CENTER_W =  int(pygame.display.Info().current_w /2)
CENTER_H =  int(pygame.display.Info().current_h /2)

#new background surface
background = pygame.Surface(window.get_size())
background = background.convert_alpha()
background.fill((26, 26, 26))

#Enter the mainloop.
main()

pygame.quit()
sys.exit(0)
